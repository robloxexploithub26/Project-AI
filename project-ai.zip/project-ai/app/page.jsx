"use client";

import { useState } from "react";
import ProjectAICore from "@/components/ProjectAICore";
import ChatInterface from "@/components/ChatInterface";

export default function Home() {
  // "idle" | "listening" | "thinking" | "responding" | "error"
  const [coreState, setCoreState] = useState("idle");

  return (
    <main className="app">
      <header className="topbar">
        <div className="brand">
          <span className="brand-name">PROJECT AI</span>
          <span className="brand-sub">by DP Studios</span>
        </div>
        <span className="sys-tag">SYS ONLINE</span>
      </header>

      <section className="stage">
        <ProjectAICore state={coreState} />
      </section>

      <ChatInterface setCoreState={setCoreState} />
    </main>
  );
}
