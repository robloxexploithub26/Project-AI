import "./globals.css";

export const metadata = {
  title: "Project AI",
  description: "Project AI — a personal AI assistant by DP Studios.",
  icons: { icon: "/favicon.svg" },
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#02060d",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
