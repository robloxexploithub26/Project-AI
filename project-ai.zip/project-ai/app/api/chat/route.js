import { NextResponse } from "next/server";
import {
  buildSystemMessage,
  PROJECT_AI_MODEL,
  PROJECT_AI_LIMITS,
} from "@/lib/projectAIConfig";

// Runs on the server only. The system prompt and API key never reach the browser.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 30;

const GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function reply(body, status = 200) {
  return NextResponse.json(body, {
    status,
    headers: { "Cache-Control": "no-store" },
  });
}

function fail(status, code, message) {
  return reply({ error: { code, message } }, status);
}

// Best-effort rate limiter. On Vercel each serverless instance has its own
// memory, so this only slows casual abuse. For a real limit, use a shared
// store such as Upstash Redis (see README).
const hits = new Map();

function rateLimited(ip) {
  const now = Date.now();
  const { rateLimitMax, rateLimitWindowMs } = PROJECT_AI_LIMITS;

  if (hits.size > 5000) {
    for (const [key, entry] of hits) {
      if (entry.reset <= now) hits.delete(key);
    }
  }

  const entry = hits.get(ip);
  if (!entry || entry.reset <= now) {
    hits.set(ip, { count: 1, reset: now + rateLimitWindowMs });
    return false;
  }
  entry.count += 1;
  return entry.count > rateLimitMax;
}

function sameOrigin(request) {
  const origin = request.headers.get("origin");
  if (!origin) return true; // non-browser or same-origin GET-style request
  try {
    return new URL(origin).host === request.headers.get("host");
  } catch {
    return false;
  }
}

// Only user/assistant turns from the client are ever accepted. Any "system"
// (or other) role is dropped, so the client cannot inject instructions.
function sanitizeHistory(raw) {
  if (!Array.isArray(raw)) return [];
  const { maxHistoryMessages, maxHistoryMessageChars } = PROJECT_AI_LIMITS;

  return raw
    .filter(
      (m) =>
        m &&
        typeof m === "object" &&
        (m.role === "user" || m.role === "assistant") &&
        typeof m.content === "string" &&
        m.content.trim().length > 0
    )
    .slice(-maxHistoryMessages)
    .map((m) => ({
      role: m.role,
      content: m.content.slice(0, maxHistoryMessageChars),
    }));
}

// ---------------------------------------------------------------------------
// POST /api/chat
// ---------------------------------------------------------------------------
export async function POST(request) {
  // 1. Basic request checks
  if (!sameOrigin(request)) {
    return fail(403, "forbidden", "This request was not allowed.");
  }

  const ip =
    request.headers.get("x-forwarded-for")?.split(",")[0].trim() || "unknown";
  if (rateLimited(ip)) {
    return fail(429, "rate_limited", "Too many requests. Please wait a moment.");
  }

  // 2. Parse and validate the body
  let data;
  try {
    const text = await request.text();
    if (text.length > PROJECT_AI_LIMITS.maxBodyBytes) {
      return fail(400, "too_large", "That request is too large.");
    }
    data = JSON.parse(text);
  } catch {
    return fail(400, "bad_json", "The request could not be read.");
  }

  const message = typeof data?.message === "string" ? data.message.trim() : "";
  if (!message) {
    return fail(400, "empty_message", "Please enter a message.");
  }
  if (message.length > PROJECT_AI_LIMITS.maxMessageChars) {
    return fail(400, "message_too_long", "That message is too long.");
  }

  // 3. Server-side configuration
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) {
    console.error("[Project AI] GROQ_API_KEY is not configured.");
    return fail(500, "not_configured", "Project AI is not configured yet.");
  }
  const model = process.env.GROQ_MODEL || PROJECT_AI_MODEL.defaultModel;

  // 4. The SERVER builds the final message array. The system message is
  //    always first and always comes from lib/projectAIConfig.js.
  const messages = [
    buildSystemMessage(),
    ...sanitizeHistory(data?.messages),
    { role: "user", content: message },
  ];

  // 5. Call the inference provider
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), PROJECT_AI_MODEL.timeoutMs);

  let upstream;
  try {
    upstream = await fetch(GROQ_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages,
        temperature: PROJECT_AI_MODEL.temperature,
        max_tokens: PROJECT_AI_MODEL.maxTokens,
        stream: false,
      }),
      signal: controller.signal,
    });
  } catch (err) {
    clearTimeout(timer);
    console.error("[Project AI] Provider request failed:", err?.name || "error");
    return fail(503, "unavailable", "Project AI is temporarily unavailable.");
  }
  clearTimeout(timer);

  // 6. Map provider errors to safe responses (details are logged, not returned)
  if (!upstream.ok) {
    console.error("[Project AI] Provider returned status", upstream.status);
    if (upstream.status === 429) {
      return fail(429, "rate_limited", "Project AI is busy. Please try again shortly.");
    }
    if (upstream.status === 401 || upstream.status === 403) {
      return fail(500, "not_configured", "Project AI is not configured correctly.");
    }
    if (upstream.status === 400 || upstream.status === 404) {
      return fail(500, "server_error", "Project AI hit a problem.");
    }
    return fail(503, "unavailable", "Project AI is temporarily unavailable.");
  }

  let result;
  try {
    result = await upstream.json();
  } catch {
    return fail(503, "unavailable", "Project AI is temporarily unavailable.");
  }

  let text = result?.choices?.[0]?.message?.content;
  if (typeof text !== "string" || !text.trim()) {
    return fail(503, "unavailable", "Project AI did not return a response.");
  }

  // Defence in depth: never let the key itself leave the server.
  text = text.split(apiKey).join("[redacted]");

  // 7. Return only what the frontend needs
  return reply({ reply: text.trim() });
}

// Anything other than POST is not supported.
export function GET() {
  return fail(405, "method_not_allowed", "Method not allowed.");
}
