# Project AI

A personal AI assistant by DP Studios. Next.js on Vercel, with Groq as the hidden inference engine.

```
USER -> Frontend (page.jsx, ProjectAICore, ChatInterface)
     -> /api/chat  (app/api/chat/route.js)
     -> Project AI config (lib/projectAIConfig.js)   <- identity, rules, system prompt
     -> Groq API  (key from process.env.GROQ_API_KEY)
     -> /api/chat -> Frontend -> USER
```

## Where things live

| File | Purpose |
| --- | --- |
| `lib/projectAIConfig.js` | Project AI's identity, rules, system prompt, model + limits. **Server only.** Edit rules here. |
| `app/api/chat/route.js` | Secure endpoint. Validates input, builds the message array, calls Groq, returns `{ reply }`. |
| `components/ProjectAICore.jsx` | Animated SVG core. `<ProjectAICore state="idle" />` |
| `components/ChatInterface.jsx` | Chat UI. Drives the core state and calls `/api/chat`. |
| `app/page.jsx` | Holds `coreState` / `setCoreState` and lays out core + chat. |
| `app/globals.css` | All styling and core animations. |
| `.env.example` | Template for `.env.local` (no real key). |

## Run locally

```bash
npm install
cp .env.example .env.local     # then edit .env.local and paste your key
npm run dev
```

Open http://localhost:3000.

`.env.local` contains:

```
GROQ_API_KEY=YOUR_KEY_HERE
```

It is already in `.gitignore`. Get a key at https://console.groq.com/keys.

## Deploy to Vercel

1. Push this folder to a GitHub repository (make sure `.env.local` is not committed).
2. In Vercel: **Add New... > Project**, import the repository. Framework preset: **Next.js** (auto-detected).
3. Before deploying, open **Environment Variables** and add:
   - Name: `GROQ_API_KEY`
   - Value: your Groq key
   - Environments: Production, Preview, Development
   - Do **not** prefix it with `NEXT_PUBLIC_` (that would expose it to the browser).
4. Click **Deploy**. If you add or change the variable later, **redeploy** for it to take effect (Deployments > ... > Redeploy).
5. Test the endpoint:
   ```bash
   curl -X POST https://YOUR-APP.vercel.app/api/chat \
     -H "Content-Type: application/json" \
     -d '{"message":"Who are you?","messages":[]}'
   ```
   You should get `{"reply":"..."}` with Project AI identifying itself.
6. Confirm the key is not exposed: open the site, DevTools > Network / Sources, and search the loaded JavaScript for `GROQ` or `gsk_`. Neither should appear. Only `/api/chat` is called, never `api.groq.com`.

Optional: set `GROQ_MODEL` in Vercel to switch models without a code change. Check https://console.groq.com/docs/models for current model IDs.

## Security notes

- The system prompt is built on the server. The client may only send `user` / `assistant` turns; any `system` role is discarded.
- Limits: 4000 chars per message, 20 history turns, 100 KB body.
- Same-origin check on the endpoint, no-store caching, generic error messages (details only in server logs).
- **Rate limiting:** the built-in limiter is in memory per serverless instance, so it only slows casual abuse. For a real limit on Vercel, use a shared store, e.g. Upstash Redis with `@upstash/ratelimit` (via the Vercel Marketplace), keyed by IP or user ID. Vercel's WAF rate-limiting rules (Firewall tab) are also an option.
- The model is instructed never to reveal its instructions, but no prompt is a guarantee. Never put secrets in the system prompt.

## Growing Project AI later

The pieces are separated so you can extend without rewriting:

- **Voice / TTS / mic visualiser:** add a hook that calls `setCoreState("listening")` / `"responding"`; the core already reacts. Loosen `Permissions-Policy` for the microphone in `next.config.js`.
- **Conversation history / accounts / memory:** swap the `messages` state in `ChatInterface` for a database, and add auth in `route.js`.
- **Multiple models / modes:** add presets to `projectAIConfig.js` and pass a `mode` from the client (validated against an allow-list on the server).
- **Tool calling / web search:** extend the request in `route.js` with `tools` and loop on tool calls server-side.
- **Streaming:** switch `stream: true` in `route.js` and read the stream in `ChatInterface`.
