"use client";

import { useCallback, useEffect, useRef, useState } from "react";

// Friendly, user-safe messages keyed by HTTP status. Raw server/provider
// errors are never shown.
const ERROR_MESSAGES = {
  400: "I couldn't process that request. Please check your message and try again.",
  401: "Project AI isn't configured correctly right now.",
  403: "That request wasn't allowed.",
  429: "I'm receiving a lot of requests. Give me a moment, then try again.",
  500: "Something went wrong on my side. Please try again shortly.",
  503: "Project AI is temporarily unavailable. Please try again in a moment.",
};
const NETWORK_ERROR = "I couldn't reach Project AI. Check your connection and try again.";
const FALLBACK_ERROR = "Something unexpected happened. Please try again.";

const SUGGESTIONS = [
  "Who are you?",
  "What can you help me with?",
  "Plan my day",
];

// Reveals assistant text progressively so the core can stay in "responding"
// while Project AI is "speaking".
function TypedText({ text, animate, onProgress, onDone }) {
  const [shown, setShown] = useState(animate ? 0 : text.length);
  const doneRef = useRef(false);

  useEffect(() => {
    if (!animate) return;
    const reduce =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setShown(text.length);
      if (!doneRef.current) {
        doneRef.current = true;
        onDone?.();
      }
      return;
    }
    const step = Math.max(1, Math.ceil(text.length / 180)); // ~3s max
    const id = setInterval(() => {
      setShown((n) => {
        const next = Math.min(text.length, n + step);
        if (next >= text.length) {
          clearInterval(id);
          if (!doneRef.current) {
            doneRef.current = true;
            setTimeout(() => onDone?.(), 0);
          }
        }
        return next;
      });
      onProgress?.();
    }, 16);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text, animate]);

  return <>{text.slice(0, shown)}</>;
}

export default function ChatInterface({ setCoreState }) {
  const [messages, setMessages] = useState([]); // { id, role, content, typing }
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");

  const listRef = useRef(null);
  const inputRef = useRef(null);
  const errorTimer = useRef(null);
  const idRef = useRef(0);

  const nextId = () => ++idRef.current;

  const scrollToBottom = useCallback(() => {
    const el = listRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, notice, scrollToBottom]);

  useEffect(() => () => clearTimeout(errorTimer.current), []);

  function autoGrow(el) {
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 120) + "px";
  }

  function handleChange(e) {
    const value = e.target.value;
    setInput(value);
    autoGrow(e.target);
    if (notice) setNotice("");
    // User is communicating with Project AI
    setCoreState(value.trim() ? "listening" : "idle");
  }

  async function send(textOverride) {
    const text = (textOverride ?? input).trim();
    if (!text || busy) return;

    clearTimeout(errorTimer.current);
    setNotice("");

    // Previous completed turns only; the server adds the system prompt itself.
    const history = messages
      .filter((m) => !m.typing)
      .map(({ role, content }) => ({ role, content }));

    setMessages((prev) => [...prev, { id: nextId(), role: "user", content: text }]);
    setInput("");
    if (inputRef.current) inputRef.current.style.height = "auto";
    setBusy(true);
    setCoreState("thinking");

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, messages: history }),
      });

      let data = null;
      try {
        data = await res.json();
      } catch {
        /* non-JSON response */
      }

      if (!res.ok || typeof data?.reply !== "string") {
        const err = new Error("request failed");
        err.status = res.status;
        throw err;
      }

      setMessages((prev) => [
        ...prev,
        { id: nextId(), role: "assistant", content: data.reply, typing: true },
      ]);
      setCoreState("responding");
      // busy is released in finishTyping()
    } catch (err) {
      const friendly = err?.status
        ? ERROR_MESSAGES[err.status] || FALLBACK_ERROR
        : NETWORK_ERROR;

      // Take the failed message back out and restore it so it can be retried.
      setMessages((prev) => prev.slice(0, -1));
      setInput(text);
      setNotice(friendly);
      setBusy(false);
      setCoreState("error");
      errorTimer.current = setTimeout(() => setCoreState("idle"), 3500);
    }
  }

  function finishTyping(id) {
    setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, typing: false } : m)));
    setBusy(false);
    setCoreState("idle");
  }

  function handleKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  function newConversation() {
    clearTimeout(errorTimer.current);
    setMessages([]);
    setInput("");
    setNotice("");
    setBusy(false);
    setCoreState("idle");
  }

  const empty = messages.length === 0;

  return (
    <section className="chat" aria-label="Conversation with Project AI">
      <div className="chat-head">
        <span className="chat-title">SESSION</span>
        <button
          type="button"
          className="ghost-btn"
          onClick={newConversation}
          disabled={empty && !input && !notice}
        >
          New
        </button>
      </div>

      <div className="messages" ref={listRef}>
        {empty && (
          <div className="welcome">
            <p>Project AI online. How can I help?</p>
            <div className="chips">
              {SUGGESTIONS.map((s) => (
                <button key={s} type="button" className="chip" onClick={() => send(s)}>
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m) => (
          <div key={m.id} className={`msg msg-${m.role}`}>
            <span className="msg-who">{m.role === "user" ? "YOU" : "PROJECT AI"}</span>
            <div className="msg-body">
              {m.role === "assistant" ? (
                <TypedText
                  text={m.content}
                  animate={!!m.typing}
                  onProgress={scrollToBottom}
                  onDone={() => finishTyping(m.id)}
                />
              ) : (
                m.content
              )}
            </div>
          </div>
        ))}

        {busy && !messages.some((m) => m.typing) && (
          <div className="msg msg-assistant">
            <span className="msg-who">PROJECT AI</span>
            <div className="msg-body thinking-dots" aria-label="Project AI is thinking">
              <i />
              <i />
              <i />
            </div>
          </div>
        )}

        {notice && (
          <div className="notice" role="alert">
            {notice}
          </div>
        )}
      </div>

      <form
        className="composer"
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
      >
        <textarea
          ref={inputRef}
          value={input}
          rows={1}
          maxLength={4000}
          placeholder="Message Project AI…"
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          onBlur={() => {
            if (!busy && !input.trim()) setCoreState("idle");
          }}
          disabled={busy}
          aria-label="Message Project AI"
        />
        <button type="submit" className="send-btn" disabled={busy || !input.trim()}>
          Send
        </button>
      </form>
    </section>
  );
}
