// The animated Project AI Core.
// Pure SVG + CSS (see globals.css) — no images, no canvas, no JS animation loop,
// so it stays smooth on phones. The state only flips a data attribute; the CSS
// does all the motion.

export const CORE_STATES = ["idle", "listening", "thinking", "responding", "error"];

const LABELS = {
  idle: "STANDBY",
  listening: "LISTENING",
  thinking: "PROCESSING",
  responding: "RESPONDING",
  error: "SYSTEM FAULT",
};

export default function ProjectAICore({ state = "idle", className = "" }) {
  const safeState = CORE_STATES.includes(state) ? state : "idle";

  return (
    <div className={`core ${className}`} data-state={safeState}>
      <svg
        className="core-svg"
        viewBox="0 0 400 400"
        role="img"
        aria-label={`Project AI core: ${LABELS[safeState].toLowerCase()}`}
      >
        <defs>
          <radialGradient id="pai-disc" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="var(--c)" stopOpacity="0.38" />
            <stop offset="70%" stopColor="var(--c)" stopOpacity="0.1" />
            <stop offset="100%" stopColor="var(--c)" stopOpacity="0.02" />
          </radialGradient>
          <radialGradient id="pai-halo" cx="50%" cy="50%" r="50%">
            <stop offset="55%" stopColor="var(--c)" stopOpacity="0" />
            <stop offset="80%" stopColor="var(--c)" stopOpacity="0.18" />
            <stop offset="100%" stopColor="var(--c)" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Ambient halo */}
        <circle className="halo" cx="200" cy="200" r="198" fill="url(#pai-halo)" />

        {/* Static fine guide rings */}
        <circle className="guide" cx="200" cy="200" r="192" />
        <circle className="guide faint" cx="200" cy="200" r="164" />

        {/* Outer tick ring */}
        <g className="spin spin-a">
          <circle className="ticks" cx="200" cy="200" r="184" />
        </g>

        {/* Thick segmented band */}
        <g className="spin spin-b">
          <circle className="band" cx="200" cy="200" r="150" />
        </g>

        {/* Accent arcs (amber) */}
        <g className="spin spin-c">
          <circle className="arc accent" cx="200" cy="200" r="134" />
        </g>

        {/* Fine inner tick ring */}
        <g className="spin spin-d">
          <circle className="ticks fine" cx="200" cy="200" r="120" />
        </g>

        {/* Fast scanner ring */}
        <g className="spin spin-e">
          <circle className="arc scanner" cx="200" cy="200" r="104" />
        </g>

        {/* Waveform ring (active when responding / listening) */}
        <circle className="wave" cx="200" cy="200" r="92" />

        {/* Core disc */}
        <circle className="disc" cx="200" cy="200" r="82" fill="url(#pai-disc)" />
        <circle className="disc-edge" cx="200" cy="200" r="82" />

        {/* Energy pulses (expanding rings) */}
        <circle className="pulse pulse-1" cx="200" cy="200" r="82" />
        <circle className="pulse pulse-2" cx="200" cy="200" r="82" />

        {/* Centre mark */}
        <g className="mark">
          <text x="200" y="192" className="mark-small" textAnchor="middle">
            PROJECT
          </text>
          <text x="200" y="226" className="mark-big" textAnchor="middle">
            AI
          </text>
        </g>
      </svg>

      <div className="core-readout" aria-live="polite">
        <span className="core-dot" />
        {LABELS[safeState]}
      </div>
    </div>
  );
}
